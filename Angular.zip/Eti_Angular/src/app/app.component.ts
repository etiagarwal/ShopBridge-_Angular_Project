import { Component } from '@angular/core';
import {ServiceService} from './service.service';
import { FormGroup, FormControl,Validators } from '@angular/forms'; 
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'EmployeeFrontEnd';
  constructor(private ServiceService: ServiceService) { }
  data: any;
  EmpForm: FormGroup;
  submitted = false; 
  EventValue: any = "Save";

  ngOnInit(): void {
    this.getdata();

    this.EmpForm = new FormGroup({
      empId: new FormControl(null),
      Name: new FormControl("",[Validators.required]),      
      Description: new FormControl("",[Validators.required]),
      Price:new FormControl("",[Validators.required]),
    })  
  }
  getdata() {
    this.ServiceService.getData().subscribe((data: any[]) => {
      this.data = data;
    })
  }
  deleteData(id) {
    this.ServiceService.deleteData(id).subscribe((data: any[]) => {
      this.data = data;
      this.getdata();
    })
  }
  Save() { 
    this.submitted = true;
  
     if (this.EmpForm.invalid) {
            return;
     }
    this.ServiceService.postData(this.EmpForm.value).subscribe((data: any[]) => {
      this.data = data;
      this.resetFrom();

    })
  }
  Update() { 
    this.submitted = true;
  
    if (this.EmpForm.invalid) {
     return;
    }      
    this.ServiceService.putData(this.EmpForm.value.empId,this.EmpForm.value).subscribe((data: any[]) => {
      this.data = data;
      this.resetFrom();
    })
  }

  EditData(Data) {
    this.EmpForm.controls["empId"].setValue(Data.empId);
    this.EmpForm.controls["Name"].setValue(Data.Name);    
    this.EmpForm.controls["Description"].setValue(Data.Description);
    this.EmpForm.controls["Price"].setValue(Data.Price);
    this.EventValue = "Update";
  }

  resetFrom()
  {   
    this.getdata();
    this.EmpForm.reset();
    this.EventValue = "Save";
    this.submitted = false; 
  }
}
